<?php

namespace React\Dns;

final class RecordNotFoundException extends \Exception
{
}
