<?php


namespace TheCodingMachine\Discovery;

class InvalidArgumentException extends \InvalidArgumentException
{
}
