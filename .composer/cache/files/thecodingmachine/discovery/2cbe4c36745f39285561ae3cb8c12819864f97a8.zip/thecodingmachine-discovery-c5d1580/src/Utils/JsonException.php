<?php

declare(strict_types=1);

namespace TheCodingMachine\Discovery\Utils;

class JsonException extends \RuntimeException
{
}
