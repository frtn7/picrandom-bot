Discovery
=========

[![Latest Stable Version](https://poser.pugx.org/thecodingmachine/discovery/v/stable)](https://packagist.org/packages/thecodingmachine/discovery)
[![Total Downloads](https://poser.pugx.org/thecodingmachine/discovery/downloads)](https://packagist.org/packages/thecodingmachine/discovery)
[![Latest Unstable Version](https://poser.pugx.org/thecodingmachine/discovery/v/unstable)](https://packagist.org/packages/thecodingmachine/discovery)
[![License](https://poser.pugx.org/thecodingmachine/discovery/license)](https://packagist.org/packages/thecodingmachine/discovery)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/thecodingmachine/discovery/badges/quality-score.png?b=1.1)](https://scrutinizer-ci.com/g/thecodingmachine/discovery/?branch=1.1)
[![Build Status](https://travis-ci.org/thecodingmachine/discovery.svg?branch=1.1)](https://travis-ci.org/thecodingmachine/discovery)
[![Coverage Status](https://coveralls.io/repos/thecodingmachine/discovery/badge.svg?branch=1.1&service=github)](https://coveralls.io/github/thecodingmachine/discovery?branch=1.1)

Publish and discover assets in your PHP projects

This package helps you find "static" assets in your Composer packages.

[Check the online documentation at https://thecodingmachine.github.io/discovery](https://thecodingmachine.github.io/discovery)
