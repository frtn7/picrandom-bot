<?php

namespace BotMan\Drivers\Telegram\Exceptions;

use BotMan\BotMan\Exceptions\Base\DriverAttachmentException;

class TelegramAttachmentException extends DriverAttachmentException
{
}
