<?php

namespace BotMan\BotMan\Middleware;

/**
 * Duplicate of ApiAi, but the product got renamed.
 */
class Dialogflow extends ApiAi
{
}
