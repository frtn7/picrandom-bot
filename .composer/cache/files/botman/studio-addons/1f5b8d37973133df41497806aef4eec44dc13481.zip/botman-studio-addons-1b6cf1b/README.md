# BotMan Studio Addons

Addons used in combination with BotMan Studio.

[![Latest Version on Packagist](https://img.shields.io/packagist/v/botman/studio-addons.svg?style=flat-square)](https://packagist.org/packages/botman/studio-addons)
[![Build Status](https://travis-ci.org/botman/studio-addons.svg?branch=master)](https://travis-ci.org/botman/studio-addons)
[![codecov](https://codecov.io/gh/botman/studio-addons/branch/master/graph/badge.svg)](https://codecov.io/gh/botman/studio-addons)


## Contributing

Please see [CONTRIBUTING](CONTRIBUTING.md) for details.

## Security Vulnerabilities

If you discover a security vulnerability within BotMan, please send an e-mail to Marcel Pociot at m.pociot@gmail.com. All security vulnerabilities will be promptly addressed.

## License

BotMan is free software distributed under the terms of the MIT license.
 
