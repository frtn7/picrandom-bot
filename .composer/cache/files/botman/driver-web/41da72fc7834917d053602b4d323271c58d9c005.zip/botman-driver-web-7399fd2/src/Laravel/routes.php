<?php

Route::view('/botman/chat', 'botman-web::chat');
